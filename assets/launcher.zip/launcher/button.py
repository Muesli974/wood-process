import pygame
from abc import ABCMeta, abstractmethod

class button(metaclass=ABCMeta):
    """docstring for button."""
    image = pygame.image.load("../assets/buttonLauncher.png")
    imagePeaked = pygame.image.load("../assets/buttonLauncherPeaked.png")

    def __init__(self, position):
        self.isPeaked = False
        self.position = position
    def isMouseOn(self):
        mousePos = pygame.mouse.get_pos()
        x = -self.position[0] + mousePos[0]
        y = -self.position[1] + mousePos[1]
        return self.image.get_bounding_rect().collidepoint((x, y))

    def update(self, launcher):
        if(self.isMouseOn()):
            self.isPeaked = True
            if(pygame.mouse.get_pressed()[0]):
                self.activate(launcher)
        else:
            self.isPeaked = False
    def getImage(self):
        if(self.isPeaked):
            return self.imagePeaked
        else:
            return self.image
    def draw(self, screen):
        if(self.isPeaked):
            screen.blit(self.imagePeaked, self.position)
        else:
            screen.blit(self.image, self.position)



    def activate(self, launcher):
        # to overwrite in subclass
        pass
