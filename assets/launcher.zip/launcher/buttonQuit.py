import pygame
from button import button

class buttonQuit(button):
    """docstring for buttonQuit."""
    def __init__(self, position, caption="Quit", font="Arial"):
        button.__init__(self, position)
        self.text = caption
        self.font = pygame.font.SysFont(font, 15)

    def draw(self, screen):
        image = button.getImage(self)
        image.blit(self.font.render(self.text, 0, (0, 0, 0)), (50, 50))
        screen.blit(image, self.position)

    def activate(self, launcher):
        launcher.quit()
